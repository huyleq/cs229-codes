from math import floor
import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
from seppyio import *

modelfile=searchArgv('vmodel')
if modelfile!=False:
    vv=np.genfromtxt(modelfile)

m=vv.shape[0]
dmax=2000.

opt=searchArgv('opt')
print opt
if int(opt)==0:
    print "calculating travel times and refl coeff"
    X=np.zeros((m,3))
    for i in range(m):
        X[i,0]=2.*vv[i,0]/vv[i,1]
        X[i,1]=vv[i,0]/vv[i,1]+(dmax-vv[i,0])/vv[i,2]
        X[i,2]=(vv[i,2]-vv[i,1])/(vv[i,2]+vv[i,1])
else:
    print "reading data"
    data=read('data')
    n1,n2=from_header('data','n1','n2')
    n1=int(n1)
    n2=int(n2)
    X=np.reshape(data,(n2,n1))

vmin=1500.
vmax=4500.
dv=1000.
nvclass=int((vmax-vmin)/dv)

dmin=0.
ddepth=1000.
ndepthclass=int(dmax/ddepth)

nclass=ndepthclass*nvclass*nvclass
V=np.zeros((m,nclass))
for i in range(m):
    depthclass=int(floor(vv[i,0]/ddepth))
    v1class=int(floor((vv[i,1]-vmin)/dv))
    v2class=int(floor((vv[i,2]-vmin)/dv))
    j=depthclass+v1class*ndepthclass+v2class*ndepthclass*nvclass
    V[i,j]=1

print(X.shape,vv.shape,V.shape)

ntest=100
ptrain=get_param('ptrain')
print ptrain
ntrain = int(0.01*ptrain*(m-ntest))
X_train = X[:ntrain,:]
V_train = V[:ntrain,:]
X_test = X[m-ntest:,:]
V_test = V[m-ntest:,:]

print(X_train.shape,V_train.shape)
print(X_test.shape,V_test.shape)

num_hidden = 100
init=True
if init:
    tf.reset_default_graph()

    X_tf = tf.placeholder(tf.float32, (None, X.shape[1]))
    V_tf = tf.placeholder(tf.int32, (None, V.shape[1]))

    l1 = tf.layers.dense(X_tf, num_hidden, activation=tf.nn.sigmoid, name='l1')
    l2 = tf.layers.dense(l1, V.shape[1], activation=tf.nn.softmax, name='l2')

    loss = tf.reduce_mean(tf.losses.softmax_cross_entropy(onehot_labels=V_tf,logits=l2))
    train_op = tf.train.AdamOptimizer().minimize(loss)
    correct_prediction = tf.equal(tf.argmax(V_tf,1), tf.argmax(l2,1))
    accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))

    def test_loss():
        return sess.run(loss, feed_dict={X_tf: X_test, V_tf: V_test})

    def test_prediction():
        return sess.run(l2, feed_dict={X_tf: X_test, V_tf: V_test})

    def train_test_accuracy():
        train_accu=sess.run(accuracy,feed_dict={X_tf:X_train,V_tf:V_train})
        test_accu=sess.run(accuracy,feed_dict={X_tf:X_test,V_tf:V_test})
        return train_accu,test_accu

    sess = tf.Session()
    sess.run(tf.global_variables_initializer())

nbatch=10
batch_size=m/nbatch
trainaccu=[]
testaccu=[]
trainloss=[]
testloss=[]
nstep=10001
rate=100
for step in range(nstep):
    for batch in range(nbatch):
        x_batch = X_train[batch*batch_size:(batch+1)*batch_size, :]
        v_batch = V_train[batch*batch_size:(batch+1)*batch_size, :]
        _, l = sess.run([train_op, loss], feed_dict={X_tf: x_batch, V_tf: v_batch})
    if step % rate == 0:
        ll=test_loss()
        trainloss.append(l)
        testloss.append(ll)
        a,b=train_test_accuracy();
        trainaccu.append(a)
        testaccu.append(b)
        print "step %d train loss %f test loss %f train accu %f test accu %f\n" % (step,l,ll,a,b)

print(test_loss())

write('trainloss',np.array(trainloss))
to_header('trainloss','n1',len(trainloss),'o1',rate,'d1',rate)

write('testloss',np.array(testloss))
to_header('testloss','n1',len(testloss),'o1',rate,'d1',rate)

write('trainaccu',np.array(trainaccu))
to_header('trainaccu','n1',len(trainaccu),'o1',rate,'d1',rate)

write('testaccu',np.array(testaccu))
to_header('testaccu','n1',len(testaccu),'o1',rate,'d1',rate)

V_predict=test_prediction()
write('vpredict',V_predict)
to_header('vpredict','n1',nclass,'o1',0.,'d1',1.)
to_header('vpredict','n2',ntest,'o2',0.,'d2',1)

write('vtest',V_test)
to_header('vtest','n1',nclass,'o1',0.,'d1',1.)
to_header('vtest','n2',ntest,'o2',0.,'d2',1)


