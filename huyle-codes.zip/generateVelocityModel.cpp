#include <cstdio>
#include "myio.h"
#include "mylib.h"

using namespace std;

int main(int argc,char **argv){
 myio_init(argc,argv);

 int nz;
 float dz,oz;
 get_param("nz",nz,"oz",oz,"dz",dz);

 float *v=new float[nz]();

 int nn;
 float depth,v1,v2;
 
 ifstream in;
 
 string velocityfile=get_s("velocityfile");
 fprintf(stderr,"velocity file %s\n",velocityfile.c_str());
 
 if(open_file(in,velocityfile)){
  string line;
  while(getline(in,line)){
   size_t pos1=line.find(" ");
   size_t pos2=line.find(" ",pos1+1);
   depth=stod(line.substr(0,pos1));
   v1=stod(line.substr(pos1+1,pos2));
   v2=stod(line.substr(pos2+1,line.length()-1));
   fprintf(stderr,"depth %f v1 %f v2 %f\n",depth,v1,v2);
   int idepth=depth/dz+1;
   set(v,v1,idepth);
   set(v+idepth,v2,nz-idepth);
   write("v",v,nz,"native_float",ios_base::app);
   nn+=1;
  }
 }
 
 to_header("v","n1",nz,"d1",dz,"o1",0.);
 to_header("v","n2",nn,"d2",1.,"o2",0.);
 
 delete []v;
 myio_close();
 return 0;
}
