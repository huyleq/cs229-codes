#include <stdio.h>
#include <fstream>
#include <string>
#include <cmath>
#include <cstring>
#include "mylib.h"
#include <omp.h>
#include "myio.h"

#define pi 3.14159265359    
#define DAMPER 0.95
#define c0 -2.84722222222
#define c1 1.6
#define c2 -0.2
#define c3 0.02539682539
#define c4 -0.00178571428


using namespace std;

void ricker(float *wavelet,float f,int nt,float dt){
 float tdelay=1.2/f;
 #pragma omp parallel for num_threads(16) 
 for(int it=0;it<nt;++it){
  float t=(it-1.)*dt;
  wavelet[it]=(1.-2.*pi*pi*f*f*(t-tdelay)*(t-tdelay))*exp(-pi*pi*f*f*(t-tdelay)*(t-tdelay));
  wavelet[it]*=1e6;
 }
 return;
}

void init_abc(float *taper,int npad){
 #pragma omp parallel for num_threads(16) 
 for(int i=0;i<npad;++i){
  taper[i]=DAMPER+(1.-DAMPER)*cos(pi*(float)(npad-1-i)/npad);
 }
 return;
}

void abc(float *u,const float *taper,int nnz,int npad){
 #pragma omp parallel for num_threads(16)
 for(int i=0;i<npad;++i){
  u[i]*=taper[i];
  u[nnz-1-i]*=taper[i];
 }
 return;
}

int main(int argc,char **argv){
 myio_init(argc,argv);

 int nz,nt,npad;
 float dz,dt,rate;
 get_param("nz",nz,"dz",dz,"npad",npad);
 get_param("nt",nt,"dt",dt,"rate",rate);
 
 int nnz=nz+2*npad,ratio=rate/dt,nnt=(nt-1)/ratio+1;
 float dz2=dz*dz,dt2=dt*dt;
 
 float *taper=new float[npad]();
 init_abc(taper,npad);
 
 float *wavelet=new float[nt]();
 float f; 
 get_param("f",f);
 ricker(wavelet,f,nt,dt);

 int nn;
 from_header("v","n2",nn);
 float *v=new float[nz*nn]();
 read("v",v,nz*nn);

 float *vv2=new float[nnz]();
 float *u0=new float[nnz]();
 float *u1=new float[nnz]();
 float *refl=new float[nnt]();
 float *trans=new float[nnt]();

 for(int i=0;i<nn;++i){
  fprintf(stderr,"i %d\n",i);

  set(vv2,v[i*nz],npad);
  memcpy(vv2+npad,v+i*nz,nz*sizeof(float));
  set(vv2+nz+npad,v[nz-1+i*nz],npad);

  multiply(vv2,vv2,vv2,nnz);
 
  u1[npad]+=wavelet[0]*dt2;

  abc(u1,taper,nnz,npad);
  
  for(int it=2;it<nt;++it){
  #pragma omp parallel for num_threads(16) 
   for(int iz=4;iz<nnz-4;++iz){
    float lap=c0*u1[iz]+c1*(u1[iz+1]+u1[iz-1])
                       +c2*(u1[iz+2]+u1[iz-2])
                       +c3*(u1[iz+3]+u1[iz-3])
                       +c4*(u1[iz+4]+u1[iz-4]);
    u0[iz]=dt2*vv2[iz]*lap/dz2+2.*u1[iz]-u0[iz];
   }
   
   u0[npad]+=wavelet[it-1]*dt2;
   
   abc(u0,taper,nnz,npad);
   abc(u1,taper,nnz,npad);
   
   if(it%ratio==0){
    refl[it/ratio]=u0[npad];
    trans[it/ratio]=u0[npad+nz];
   }
   
   float *pt=u0;u0=u1;u1=pt;
  }
 
  write("refl",refl,nnt,"native_float",ios_base::app);
  write("trans",trans,nnt,"native_float",ios_base::app);
 }
 
 to_header("refl","n1",nnt,"d1",rate,"o1",0.);
 to_header("refl","n2",nn,"d2",1.,"o2",0.);
 to_header("trans","n1",nnt,"d1",rate,"o1",0.);
 to_header("trans","n2",nn,"d2",1.,"o2",0.);

 delete []taper;delete []v;delete []vv2;delete []u0;delete []u1;delete []refl;delete []trans;
 myio_close();
 return 0;
}
