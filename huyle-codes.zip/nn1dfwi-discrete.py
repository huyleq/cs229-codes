import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
from seppyio import *

data=read('data')
n1,n2=from_header('data','n1','n2')
n1=int(n1)
n2=int(n2)
X=np.reshape(data,(n2,n1))

V=read('vmodel')
n1,n2=from_header('vmodel','n1','n2')
n1=int(n1)
n2=int(n2)
V=np.reshape(V,(n2,n1))
vmin=1500
vmax=4500
V=(V-vmin)/(vmax-vmin)

print(X.shape,V.shape)

m=X.shape[0]
ntest=100
ptrain=get_param('ptrain')
print ptrain
ntrain = int(0.01*ptrain*(m-ntest))
X_train = X[:ntrain,:]
V_train = V[:ntrain,:]
X_test = X[m-ntest:,:]
V_test = V[m-ntest:,:]

print(X_train.shape,V_train.shape)
print(X_test.shape,V_test.shape)

num_hidden = 100
init=True
if init:
    tf.reset_default_graph()

    X_tf = tf.placeholder(tf.float32, (None, X.shape[1]))
    V_tf = tf.placeholder(tf.int32, (None, V.shape[1]))

    l1 = tf.layers.dense(X_tf, num_hidden, activation=tf.nn.sigmoid, name='l1')
    l2 = tf.layers.dense(l1, V.shape[1], activation=tf.nn.softmax, name='l2')

    loss = tf.losses.mean_squared_error(V_tf, l2)
    train_op = tf.train.AdamOptimizer().minimize(loss)

    batch_size=50

    def test_loss():
        return sess.run(loss, feed_dict={X_tf: X_test, V_tf: V_test})

    def test_prediction():
        return sess.run(l2, feed_dict={X_tf: X_test, V_tf: V_test})


    sess = tf.Session()
    sess.run(tf.global_variables_initializer())

trainloss=[]
testloss=[]
nstep=20000
rate=1000
for step in range(nstep):
    _, l = sess.run([train_op, loss], feed_dict={X_tf: X_train, V_tf: V_train})
    if step % rate == 0:
        ll=test_loss()
        trainloss.append(l)
        testloss.append(ll)
        print(step,l,ll)

print(test_loss())

write('trainloss',np.array(trainloss))
to_header('trainloss','n1',len(trainloss),'o1',rate,'d1',rate)

write('testloss',np.array(testloss))
to_header('testloss','n1',len(testloss),'o1',rate,'d1',rate)

V_predicted=test_prediction()

V_test=V_test*(vmax-vmin)+vmin
V_predicted=V_predicted*(vmax-vmin)+vmin

dz=12.5
n2,n1=V_test.shape

write('vtest',V_test)
to_header('vtest','n1',n1,'o1',0.,'d1',dz)
to_header('vtest','n2',n2,'o2',0.,'d2',1)

write('vpredict',V_predicted)
to_header('vpredict','n1',n1,'o1',0.,'d1',dz)
to_header('vpredict','n2',n2,'o2',0.,'d2',1)
