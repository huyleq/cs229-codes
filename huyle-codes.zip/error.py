
import numpy as np
import matplotlib.pyplot as plt
from seppyio import *

n1,n2=from_header('vpredict','n1','n2')
n1=int(n1)
n2=int(n2)
vpredict=read('vpredict')
vpredict=np.reshape(vpredict,(n2,n1))

n1,n2=from_header('vtest','n1','n2')
n1=int(n1)
n2=int(n2)
vtest=read('vtest')
vtest=np.reshape(vtest,(n2,n1))

ntest=100
modelfile=searchArgv('vmodel')
if modelfile!=False:
    vv=np.genfromtxt(modelfile)
m=vv.shape[0]
v=vv[m-ntest:,:]

depthconfusion=np.zeros((2,2))
v1confusion=np.zeros((3,3))
v2confusion=np.zeros((3,3))

for i in range(ntest):
    j=np.argmax(vtest[i,:])
    k=np.argmax(vpredict[i,:])
    depthclass0=j%2
    v1class0=(j%6-depthclass0)/2
    v2class0=j/6
    depthclass1=k%2
    v1class1=(k%6-depthclass1)/2
    v2class1=k/6
    depthconfusion[depthclass0,depthclass1]+=1
    v1confusion[v1class0,v1class1]+=1
    v2confusion[v2class0,v2class1]+=1

write('depthconfusion',depthconfusion/100.)
to_header('depthconfusion','n1',depthconfusion.shape[1],'o1',0.,'d1',1.)
to_header('depthconfusion','n2',depthconfusion.shape[0],'o2',0.,'d2',1.)

write('v1confusion',v1confusion/100.)
to_header('v1confusion','n1',v1confusion.shape[1],'o1',0.,'d1',1.)
to_header('v1confusion','n2',v1confusion.shape[0],'o2',0.,'d2',1.)

write('v2confusion',v2confusion/100.)
to_header('v2confusion','n1',v2confusion.shape[1],'o1',0.,'d1',1.)
to_header('v2confusion','n2',v2confusion.shape[0],'o2',0.,'d2',1)

fig, ax = plt.subplots(1,1)
cax=ax.imshow(depthconfusion,interpolation='none')
fig.colorbar(cax)
axs[1].imshow(v1confusion,interpolation='none')
axs[2].imshow(v2confusion,interpolation='none')
plt.show()

print "average error",np.mean(np.absolute(vtest-vpredict))

plt.plot(np.mean(np.absolute(vtest-vpredict),axis=1))
plt.show()

nfail=0
nfaildepth=0
nfailv1=0 
nfailv2=0
for i in range(ntest):
    j=np.argmax(vtest[i,:])
    k=np.argmax(vpredict[i,:])
    if k!=j:
        nfail+=1
        depthclass0=j%2
        v1class0=(j%6-depthclass0)/2
        v2class0=j/6
        depthclass1=k%2
        v1class1=(k%6-depthclass1)/2
        v2class1=k/6
        if depthclass0!=depthclass1:
            nfaildepth+=1
            faildepth="x"
        else:
            faildepth=" "
        if v1class0!=v1class1:
            nfailv1+=1
            failv1="x"
        else:
            failv1=" "
        if v2class0!=v2class1:
            nfailv2+=1
            failv2="x"
        else:
            failv2=" "
        print "%d & %s & %s & %s \\\\" % (i,faildepth,failv1,failv2)
        print "\\hline"

print "total fail %d, depth fail %d, v1 fail %d v2 fail %d" % (nfail,nfaildepth,nfailv1,nfailv2)
