import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
from seppyio import *

modelfile=searchArgv('vmodel')
if modelfile!=False:
    V=np.genfromtxt(modelfile)

m=V.shape[0]
X=np.zeros((m,3))
dmax=2000

for i in range(m):
    X[i,0]=2.*V[i,0]/V[i,1]
    X[i,1]=V[i,0]/V[i,1]+(dmax-V[i,0])/V[i,2]
    X[i,2]=(V[i,2]-V[i,1])/(V[i,2]+V[i,1])

vmin=1500
vmax=4500
V[:,1:]=(V[:,1:]-vmin)/(vmax-vmin)

dmin=0
V[:,0]=(V[:,0]-dmin)/(dmax-dmin)

print(X.shape,V.shape)

ntest=100
ptrain=get_param('ptrain')
print ptrain
ntrain = int(0.01*ptrain*(m-ntest))
X_train = X[:ntrain,:]
V_train = V[:ntrain,:]
X_test = X[m-ntest:,:]
V_test = V[m-ntest:,:]

print(X_train.shape,V_train.shape)
print(X_test.shape,V_test.shape)

num_hidden = 100
init=True
if init:
    tf.reset_default_graph()

    X_tf = tf.placeholder(tf.float32, (None, X.shape[1]))
    V_tf = tf.placeholder(tf.int32, (None, V.shape[1]))

    l1 = tf.layers.dense(X_tf, num_hidden, activation=tf.nn.sigmoid, name='l1')
    l2 = tf.layers.dense(l1, V.shape[1], activation=tf.nn.softmax, name='l2')

    loss = tf.losses.mean_squared_error(V_tf, l2)
    train_op = tf.train.AdamOptimizer().minimize(loss)

    batch_size=50

    def test_loss():
        return sess.run(loss, feed_dict={X_tf: X_test, V_tf: V_test})

    def test_prediction():
        return sess.run(l2, feed_dict={X_tf: X_test, V_tf: V_test})


    sess = tf.Session()
    sess.run(tf.global_variables_initializer())

trainloss=[]
testloss=[]
nstep=20000
rate=1000
for step in range(nstep):
    _, l = sess.run([train_op, loss], feed_dict={X_tf: X_train, V_tf: V_train})
    if step % rate == 0:
        ll=test_loss()
        trainloss.append(l)
        testloss.append(ll)
        print(step,l,ll)

print(test_loss())

write('trainloss',np.array(trainloss))
to_header('trainloss','n1',len(trainloss),'o1',rate,'d1',rate)

write('testloss',np.array(testloss))
to_header('testloss','n1',len(testloss),'o1',rate,'d1',rate)

V_predicted=test_prediction()

V_test[:,0]=V_test[:,0]*(dmax-dmin)+dmin
V_predicted[:,0]=V_predicted[:,0]*(dmax-dmin)+dmin
V_test[:,1:]=V_test[:,1:]*(vmax-vmin)+vmin
V_predicted[:,1:]=V_predicted[:,1:]*(vmax-vmin)+vmin

testfile=searchArgv('test')
predict=searchArgv('predict')

ftest=open(testfile,'a+')
fpredict=open(predict,'a+')

for i in range(ntest):
    ftest.write('%f %f %f\n' % (V_test[i,0],V_test[i,1],V_test[i,2]))
    fpredict.write('%f %f %f\n' % (V_predicted[i,0],V_predicted[i,1],V_predicted[i,2]))

ftest.close()
fpredict.close()

dz=12.5
nz=int(dmax/dz)
vtest=np.zeros((ntest,nz))
vpredict=np.zeros((ntest,nz))
for i in range(ntest):
    j=int(V_test[i,0]/dz+1)
    vtest[i,:j]=V_test[i,1]
    vtest[i,j:]=V_test[i,2]
    j=int(V_predicted[i,0]/dz+1)
    vpredict[i,:j]=V_predicted[i,1]
    vpredict[i,j:]=V_predicted[i,2]

write('vtest',vtest)
to_header('vtest','n1',nz,'o1',0.,'d1',dz)
to_header('vtest','n2',ntest,'o2',0.,'d2',1)

write('vpredict',vpredict)
to_header('vpredict','n1',nz,'o1',0.,'d1',dz)
to_header('vpredict','n2',ntest,'o2',0.,'d2',1)

