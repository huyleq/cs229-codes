import random

v=set()
while len(v)<10000:
    v.add(random.uniform(1500.,4500.))

f=open('velocity-models.txt','w')
for v1 in v:
    depth=random.uniform(0.,2000.)
    v2=random.uniform(1500.,4500.)
    f.write('%f %f %f\n' % (depth,v1,v2))

f.close()

